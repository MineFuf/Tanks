<?xml version="1.0" encoding="UTF-8"?>
<tileset name="ground" tilewidth="64" tileheight="64" tilecount="40" columns="10">
 <image source="../img/terrainTiles_default.png" width="640" height="256"/>
</tileset>
