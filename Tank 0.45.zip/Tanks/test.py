import pygame as pg

win1 = pg.display.set_mode((512, 256))
win2 = pg.display.set_mode((256, 512))
win1.fill((0, 255, 255))
win2.fill((255, 0, 0))

pg.display.flip()

while True:
    pass
